<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "filmdatenbank";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $titel = $_POST['titel'];
    $jahr = $_POST['jahr'];
    $genre = $_POST['genre'];
    $regisseur = $_POST['regisseur'];
    $beschreibung = $_POST['beschreibung'];

    if (isset($_FILES['bild']) && $_FILES['bild']['error'] == 0) {
        $bild = $_FILES['bild'];
        $bildName = basename($bild['name']);
        $bildPath = 'uploads/' . $bildName;

        if (move_uploaded_file($bild['tmp_name'], $bildPath)) {
            $bildUrl = $bildPath;
        } else {
            die("Bild hochladen fehlgeschlagen");
        }
    } else {
        die("Bild hochladen fehlgeschlagen");
    }

    // Überprüfen, ob der Film bereits existiert
    $check_sql = "SELECT * FROM filme WHERE titel = '$titel' AND jahr = '$jahr'";
    $check_result = $conn->query($check_sql);

    if ($check_result->num_rows > 0) {
        echo "Film existiert bereits in der Datenbank.";
    } else {
        $sql = "INSERT INTO filme (titel, jahr, genre, regisseur, bild_url, beschreibung) VALUES ('$titel', '$jahr', '$genre', '$regisseur', '$bildUrl', '$beschreibung')";

        if ($conn->query($sql) === TRUE) {
            echo "Neuer Film hinzugefügt";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $suche = isset($_GET['suche']) ? $_GET['suche'] : '';

    $sql = "SELECT * FROM filme WHERE titel LIKE '%$suche%'";
    $result = $conn->query($sql);

    $filme = array();

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $filme[] = $row;
        }
    }

    echo json_encode($filme);
}

$conn->close();
?>

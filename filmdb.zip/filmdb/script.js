document.addEventListener('DOMContentLoaded', function () {
    fetchFilme();

    document.getElementById('filmForm').addEventListener('submit', function (e) {
        e.preventDefault();
        addFilm();
    });
});

function fetchFilme(suche = '') {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', `backend.php?suche=${suche}`, true);
    xhr.onload = function () {
        if (this.status === 200) {
            const filme = JSON.parse(this.responseText);
            let output = '';
            filme.forEach(function (film) {
                output += `
                    <tr>
                        <td>${film.id}</td>
                        <td>${film.titel}</td>
                        <td>${film.jahr}</td>
                        <td>${film.genre}</td>
                        <td>${film.regisseur}</td>
                        <td><img src="${film.bild_url}" alt="${film.titel}"></td>
                    </tr>
                `;
            });
            document.querySelector('#filmListe tbody').innerHTML = output;
        }
    };
    xhr.send();
}

function sucheFilm() {
    const suche = document.getElementById('suche').value;
    fetchFilme(suche);
}

function addFilm() {
    const titel = document.getElementById('titel').value;
    const jahr = document.getElementById('jahr').value;
    const genre = document.getElementById('genre').value;
    const regisseur = document.getElementById('regisseur').value;
    const bild_url = document.getElementById('bild_url').value;

    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'backend.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function () {
        if (this.status === 200) {
            fetchFilme();
            document.getElementById('filmForm').reset();
        }
    };
    xhr.send(`titel=${titel}&jahr=${jahr}&genre=${genre}&regisseur=${regisseur}&bild_url=${bild_url}`);
}

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('filmForm').addEventListener('submit', function (e) {
        e.preventDefault();
        addFilm();
    });
});

function addFilm() {
    const formData = new FormData();
    formData.append('titel', document.getElementById('titel').value);
    formData.append('jahr', document.getElementById('jahr').value);
    formData.append('genre', document.getElementById('genre').value);
    formData.append('regisseur', document.getElementById('regisseur').value);
    formData.append('bild', document.getElementById('bild').files[0]);

    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'backend.php', true);
    xhr.onload = function () {
        if (this.status === 200) {
            alert('Film hinzugefügt!');
            document.getElementById('filmForm').reset();
        }
    };
    xhr.send(formData);
}
document.getElementById('filmForm').addEventListener('submit', function(e) {
    e.preventDefault();

    let titel = document.getElementById('titel').value;
    let jahr = document.getElementById('jahr').value;
    let genre = document.getElementById('genre').value;
    let regisseur = document.getElementById('regisseur').value;
    let bild_url = document.getElementById('bild_url').value;
    let beschreibung = document.getElementById('beschreibung').value; // Neue Beschreibung

    let formData = new FormData();
    formData.append('titel', titel);
    formData.append('jahr', jahr);
    formData.append('genre', genre);
    formData.append('regisseur', regisseur);
    formData.append('bild_url', bild_url);
    formData.append('beschreibung', beschreibung); // Beschreibung hinzufügen

    fetch('dein_php_script.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        console.log(data);
        // Aktualisiere die Film-Liste nach dem Hinzufügen
        sucheFilm();
    })
    .catch(error => console.error('Error:', error));
});

function sucheFilm() {
    let suche = document.getElementById('suche').value;

    fetch('dein_php_script.php?suche=' + suche)
    .then(response => response.json())
    .then(data => {
        let tbody = document.getElementById('filmListe').getElementsByTagName('tbody')[0];
        tbody.innerHTML = ''; // Bestehende Einträge löschen

        data.forEach(film => {
            let tr = document.createElement('tr');

            tr.innerHTML = `
                <td>${film.id}</td>
                <td>${film.titel}</td>
                <td>${film.jahr}</td>
                <td>${film.genre}</td>
                <td>${film.regisseur}</td>
                <td><img src="${film.bild_url}" alt="${film.titel}"></td>
                <td>${film.beschreibung}</td> <!-- Neue Beschreibung anzeigen -->
            `;

            tbody.appendChild(tr);
        });
    })
    .catch(error => console.error('Error:', error));
}

document.getElementById('filmForm').addEventListener('submit', function(e) {
    e.preventDefault();

    let titel = document.getElementById('titel').value;
    let jahr = document.getElementById('jahr').value;
    let genre = document.getElementById('genre').value;
    let regisseur = document.getElementById('regisseur').value;
    let beschreibung = document.getElementById('beschreibung').value; // Neue Beschreibung
    let bild = document.getElementById('bild').files[0];

    let formData = new FormData();
    formData.append('titel', titel);
    formData.append('jahr', jahr);
    formData.append('genre', genre);
    formData.append('regisseur', regisseur);
    formData.append('beschreibung', beschreibung); // Beschreibung hinzufügen
    formData.append('bild', bild);

    fetch('dein_php_script.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        console.log(data);
        // Aktualisiere die Film-Liste nach dem Hinzufügen
        window.location.href = 'index.html';
    })
    .catch(error => console.error('Error:', error));
});

function showForm() {
    // Alle Formulare ausblenden
    document.getElementById('filmForm').classList.add('hidden');
    document.getElementById('buchForm').classList.add('hidden');
    document.getElementById('serieForm').classList.add('hidden');

    // Die ausgewählte Kategorie abrufen
    const category = document.getElementById('category').value;

    // Das entsprechende Formular anzeigen
    if (category === 'film') {
        document.getElementById('filmForm').classList.remove('hidden');
    } else if (category === 'buch') {
        document.getElementById('buchForm').classList.remove('hidden');
    } else if (category === 'serie') {
        document.getElementById('serieForm').classList.remove('hidden');
    }
}